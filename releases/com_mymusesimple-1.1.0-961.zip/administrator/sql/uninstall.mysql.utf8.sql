-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 26, 2009 at 01:26 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.4-2ubuntu5.7

-- 
-- Database: `mymuse`
-- 

-- --------------------------------------------------------

-- 
-- 
-- 

DROP TABLE IF EXISTS `#__mymuse_country`;
DROP TABLE IF EXISTS `#__mymuse_coupon`;
DROP TABLE IF EXISTS `#__mymuse_currency`;
DROP TABLE IF EXISTS `#__mymuse_downloads`;
DROP TABLE IF EXISTS `#__mymuse_order`;
DROP TABLE IF EXISTS `#__mymuse_order_item`;
DROP TABLE IF EXISTS `#__mymuse_order_status`;

DROP TABLE IF EXISTS `#__mymuse_order_payment`;
DROP TABLE IF EXISTS `#__mymuse_product`;

DROP TABLE IF EXISTS `#__mymuse_product_category_xref`;
DROP TABLE IF EXISTS `#__mymuse_product_recommend_xref`;
DROP TABLE IF EXISTS `#__mymuse_product_file`;
DROP TABLE IF EXISTS `#__mymuse_product_rating`;
DROP TABLE IF EXISTS `#__mymuse_shopper`;
DROP TABLE IF EXISTS `#__mymuse_shopper_group`;
DROP TABLE IF EXISTS `#__mymuse_state`;
DROP TABLE IF EXISTS `#__mymuse_store`;
DROP TABLE IF EXISTS `#__mymuse_track`;
DROP TABLE IF EXISTS `#__mymuse_tax_rate`;

