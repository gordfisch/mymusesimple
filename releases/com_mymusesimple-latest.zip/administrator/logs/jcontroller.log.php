#
#<?php die('Forbidden.'); ?>
#Date: 2019-02-06 15:33:19 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2019-02-06T15:33:19+00:00	INFO 127.0.0.1	controller	Holding edit ID com_modules.edit.module.118 Array (     [0] => 118 ) 
2019-02-06T15:33:19+00:00	INFO 127.0.0.1	controller	Checking edit ID com_modules.edit.module.118: 1 Array (     [0] => 118 ) 
2019-02-06T15:33:33+00:00	INFO 127.0.0.1	controller	Holding edit ID com_modules.edit.module.118 Array (     [0] => 118 ) 
2019-02-06T15:33:33+00:00	INFO 127.0.0.1	controller	Checking edit ID com_modules.edit.module.118: 1 Array (     [0] => 118 ) 
2019-02-06T15:33:47+00:00	INFO 127.0.0.1	controller	Holding edit ID com_modules.edit.module.118 Array (     [0] => 118 ) 
2019-02-06T15:33:47+00:00	INFO 127.0.0.1	controller	Checking edit ID com_modules.edit.module.118: 1 Array (     [0] => 118 ) 
