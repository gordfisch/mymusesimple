//var dom = {};
//dom.query = jQuery.noConflict( true );