<?php 
/**
 * @version		$Id: product.php 1986 2018-07-22 19:11:13Z gfisch $
 * @package		mymuse
 * @copyright	Copyright © 2018 - Arboreta Internet Services - All rights reserved.
 * @license		GNU/GPL
 * @author		Gordon Fisch
 * @author 		info@joomlamymuse.com
 * @website		http://www.joomlamymuse.com
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
global $store, $shopper, $cart;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers');

$product 	=& $this->item;
$items		=& $this->item->items;
$tracks		=& $this->item->tracks;
$params 	=& $this->params;
$user 		=& $this->user;
$print 		= $this->print;
$Itemid		= $this->Itemid;
$height 	= $this->params->get('product_product_image_height',0);
$this->check 		= 1;
$count		= 0;
$this->return_link = 'index.php?option=com_mymuse&view=product&task=product&id='.$product->id.'&catid='.$product->catid.'&Itemid='.$Itemid;
$this->canEdit	= $this->item->params->get('access-edit',0);
$items_select 	= $this->params->get('product_item_selectbox',0);
$lang = JFactory::getLanguage();
$langtag = $lang->getTag();
$listOrder	= $this->sortColumn;
$listDirn	= $this->sortDirection;


//get artist URL if exists
$this->item->artist_link = '';
$db = JFactory::getDBO();
$artist = JApplication::stringURLSafe($this->item->artist_title);
$this->item->artist_link = '';
if($artist){
	$query = "SELECT link FROM #__menu WHERE alias = '$artist'";
	$db->setQuery($query);
	if($res = $db->loadObject()){
		$this->item->artist_link = JRoute::_($res->link);
	}
}

$uri = JFactory::getURI();
$prod_uri = $uri->toString();
$description = ($product->introtext != '')? $product->introtext : $product->title;
$document 	= JFactory::getDocument();
$document->setMetaData( 'og:site_name',$this->escape($this->store->title));
$document->setMetaData( 'og:type', 'article');
$document->setMetaData( 'og:url', $prod_uri);
$document->setMetaData( 'og:title', $this->escape($product->title));
$document->setMetaData( 'og:description', strip_tags($description));
$document->setMetaData( 'og:image', JURI::Root().$product->detail_image);

$document->setMetaData( 'twitter:title', $this->escape($product->title));
$document->setMetaData( 'twitter:card', 'summary_large_image');
$document->setMetaData( 'twitter:site', $this->params->get('twitter_handle'));
$document->setMetaData( 'twitter:creator', $this->params->get('twitter_handle'));
$document->setMetaData( 'twitter:url', $prod_uri);
$document->setMetaData( 'twitter:description', strip_tags($description));
$document->setMetaData( 'twitter:image', JURI::Root().$product->detail_image);


if("1" == $this->params->get('my_price_by_product')){//price by product
	$product_price_physical = array('product_price' => $this->item->attribs->get('product_price_physical'));

	foreach($this->params->get('my_formats') as $format){
		$str = 'product_price_'.$format;
		$$str = array('product_price' => $this->item->attribs->get($str));
		$str = 'product_price_'.$format.'_all';
		$$str = array('product_price' => $this->item->attribs->get($str));
	}
}

$this->all_tracks = 0;
if(count($tracks)){ 
    foreach($tracks as $track){ 
        if($track->product_allfiles == 1){
            $this->all_tracks = $track;
        }
    }
}

$url = "index.php?option=com_mymuse&task=ajaxtogglecart";
$this->products = array();
for ($i=0;$i<$this->cart["idx"];$i++) {
	if(isset($this->cart[$i]['product_id'])){
		$this->products[] =  $this->cart[$i]['product_id'];
	}
}

// get the count of all products, items and tracks
if($product->product_physical){
	$count++;
}
if(count($items) && !$items_select){ 
	$count += count($items);
}

if(count($tracks)){ 
	$count += count($tracks);
}

//add javascript 
$js = '

function hasProduct(that, count){
';

if($items_select && count($items)){
$js .= 	'    item_count='.count($items).';
	var pidselect=document.getElementById("pidselect");
    var pid = pidselect.options[pidselect.selectedIndex].value;
	if(pid != ""){
		return true;
	}
    ';
}
$js .= '	for(i = 1; i < count+1; i++)
	{
		var thisCheckBox = "box" + i;
		if (document.getElementById(thisCheckBox).checked)
		{
			return true;
		}
	}
	alert("'.JText::_("MYMUSE_PLEASE_SELECT_A_PRODUCT").'");
	return false;
}

function tableOrdering( order, dir, task )
{
	var form = document.adminForm;
	form.filter_order.value 	= order;
	form.filter_order_Dir.value	= dir;
	document.adminForm.submit( task );
}

Number.prototype.formatMoney = function(c, d, t){
    var n = this, 
    c = isNaN(c = Math.abs(c)) ? 2 : c, 
    d = d == undefined ? "." : d, 
    t = t == undefined ? "," : t, 
    s = n < 0 ? "-" : "", 
    i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))), 
    j = (j = i.length) > 3 ? j % 3 : 0;
   return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
 }; 
';

//flip price between formats
if(count($params->get('my_formats', array())) > 1 ){	
	
	$js .= 'function flip_price(id) {'."\n";
	$js .= ' var formats = new Array();'."\n";
	foreach($params->get('my_formats') as $index=>$format) {
		$js .= 'formats['.$index.'] = "'.$format.'"'."\n";
	}
	foreach($params->get('my_formats') as $format) {
		$js .= 'var  '.$format.'_id = "#'.$format.'_"+id'."\n";
	}
	$js .= 'var select_id = "#variation_"+id+"_id"'."\n";
    
	for($i=0; $i < count($params->get('my_formats')); $i++){
    	$js .= 'jQuery('.$params->get('my_formats')[$i].'_id).hide();'."\n";
	}   		
	$js .= '
			//alert(formats[jQuery(select_id).val()]+"_"+id);
			jQuery("#"+formats[jQuery(select_id).val()]+"_"+id).show();'."\n}";
}

//set up the ajax cart add
$url = JURI::Root()."index.php?option=com_mymuse&task=ajaxtogglecart";

if($product->product_physical){
	//cart add phyical product ajax
	$js .= '
jQuery(document).ready(function($){
		$("#box_'.$product->id.'").click(function(e){
			if(typeof document.mymuseform.variation_'.$product->id.'_id !== "undefined"){
				myvariation = document.mymuseform.variation_'.$product->id.'_id.value;
				//alert("variation = "+myvariation);
	
			}else{
				myvariation = "";
			}
            $.post("'.$url.'",
            {
                "productid":"'.$product->id.'",
                "variation['.$product->id.']":myvariation
	
            },
            function(data,status)
            {
	
                var res = jQuery.parseJSON(data);
                idx = res.idx;
                msg = res.msg;
                action = res.action;
                //alert(res.msg);
                if(action == "deleted" || action == "failed"){
                    $("#cart_image_'.$product->id.'").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/checkbox.png");
                }else{
                    $("#cart_image_'.$product->id.'").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/cart.png");
                }
                if(idx){
                    if(idx == 1){
                        txt = idx+" "+"item";
                    }else{
                        txt = idx+" "+"items";
                    }
                    link = \''.'<a href="'.JRoute::_('index.php?option=com_mymuse&task=showcart&view=cart&Itemid='.$Itemid).'">'.JText::_('MYMUSE_VIEW_CART').'</a>\';
                    $("#mini-cart-text").html(txt);
                    $("#mini-cart-link").html(link);
                }else{
	
                    $("#mini-cart-text").html(" ");
                    $("#mini-cart-link").html(\''.json_encode(JText::_('MYMUSE_YOUR_CART_IS_EMPTY')).'\');
                    link = "";
                }
                my_modal.open({content: msg+"<br />"+link, width: 300, delay:'. $params->get('my_delay_fadeout', 3000)  .' });
            });
	
		});
	});
	
';
}


$items_select 	= $this->params->get('product_item_selectbox',0);
if(count($items) && $items_select){

	$js .= '
	jQuery(document).ready(function($){
		$("#box_'.$product->id.'").click(function(e){

            $.post("'.$url.'",
            {
                "productid":current_product_id
                		
            },
            function(data,status)
            {
        		
                var res = jQuery.parseJSON(data);
                idx = res.idx;
                msg = res.msg;
                action = res.action;

                //alert(res.msg);
                if(action == "deleted" || action == "failed"){
                    $("#cart_image").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/checkbox.png");
                }else{
                    $("#cart_image").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/cart.png");
                }

                if(idx){
                    if(idx == 1){
                        txt = idx+" "+"item";
                    }else{
                        txt = idx+" "+"items";
                    }
                    link = \''.'<a href="'.JRoute::_('index.php?option=com_mymuse&task=showcart&view=cart&Itemid='.$Itemid).'">'.JText::_('MYMUSE_VIEW_CART').'</a>\';
                    $("#mini-cart-text").html(txt);
                    $("#mini-cart-link").html(link);
                }else{
	
                    $("#mini-cart-text").html(" ");
                    $("#mini-cart-link").html(\''.json_encode(JText::_('MYMUSE_YOUR_CART_IS_EMPTY')).'\');
                    link = "";
                }
                my_modal.open({content: msg+"<br />"+link, width: 300,target:'.$product->id.', delay:'. $params->get('my_delay_fadeout', 3000)  .'});
            });

		});
	});

	';
	}
if(count($items) && !$items_select){
	foreach($items as $item){
			$js .= '
			jQuery(document).ready(function($){
				$("#box_'.$item->id.'").click(function(e){

		            $.post("'.$url.'",
		            {
		                "productid":"'.$item->id.'"
		                		
		            },
		            function(data,status)
		            {
		        		
		                var res = jQuery.parseJSON(data);
		                idx = res.idx;
		                msg = res.msg;
		                action = res.action;

		                //alert(res.msg);
		                if(action == "deleted" || action == "failed"){
		                    $("#img_'.$item->id.'").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/checkbox.png");
		                }else{
		                    $("#img_'.$item->id.'").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/cart.png");
		                }

		                if(idx){
		                    if(idx == 1){
		                        txt = idx+" "+"item";
		                    }else{
		                        txt = idx+" "+"items";
		                    }
		                    link = \''.'<a href="'.JRoute::_('index.php?option=com_mymuse&task=showcart&view=cart&Itemid='.$Itemid).'">'.JText::_('MYMUSE_VIEW_CART').'</a>\';
		                        $("#mini-cart-text").html(txt);
		                        $("#mini-cart-link").html(link);
		                    }else{
		                    
		                        $("#mini-cart-text").html(" ");
		                        $("#mini-cart-link").html(\''.json_encode(JText::_('MYMUSE_YOUR_CART_IS_EMPTY')).'\');
		                        link = "";
		                }
		                my_modal.open({content: msg+"<br />"+link, width: 300,target:'.$product->id.', delay:'. $params->get('my_delay_fadeout', 3000)  .'});
		            });

				});
			});

			';
	}
}
foreach($tracks as $track){

	$js .= '
	jQuery(document).ready(function($){
		$("#box_'.$track->id.'").click(function(e){
			if(typeof document.mymuseform.variation_'.$track->id.'_id !== "undefined"){	
				myvariation = document.mymuseform.variation_'.$track->id.'_id.value;
				//alert("variation = "+myvariation);

			}else{
				myvariation = 0;
			}
            $.post("'.$url.'",
            {
                "productid":"'.$track->id.'",
                "variation['.$track->id.']":myvariation
                		
            },
            function(data,status)
            {
        
                var res = jQuery.parseJSON(data);
                idx = res.idx;
                msg = res.msg;
                action = res.action;
                //alert(res.msg);
                if(action == "deleted" || action == "failed"){
                    $("#img_'.$track->id.'").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/checkbox.png");
                }else{
                    $("#img_'.$track->id.'").attr("src","'.JURI::root().'/components/com_mymuse/assets/images/cart.png");
                }
                if(idx){
                    if(idx == 1){
                        txt = idx+" "+"item";
                    }else{
                        txt = idx+" "+"items";
                    }
                    link = \''.'<a href="'.JRoute::_('index.php?option=com_mymuse&task=showcart&view=cart&Itemid='.$Itemid).'">'.JText::_('MYMUSE_VIEW_CART').'</a>\';
                    $("#mini-cart-text").html(txt);
                    $("#mini-cart-link").html(link);
                }else{

                    $("#mini-cart-text").html(" ");
                    $("#mini-cart-link").html(\''.json_encode(JText::_('MYMUSE_YOUR_CART_IS_EMPTY')).'\');
                    link = "";
                }
                my_modal.open({content: msg+"<br />"+link, width: 300,target:'.$track->id.', delay:'. $params->get('my_delay_fadeout', 3000)  .'});
            });

		});
	});

	';
	}

$document->addScriptDeclaration($js);
?>
<!--  START PRODUCT VIEW -->

<?php echo $this->loadTemplate('heading'); ?>


<form method="post"
	action="<?php JRoute::_('index.php?lang='.$langtag) ?>"
	onsubmit="return hasProduct(this,<?php echo $count; ?>);"
	name="mymuseform">
	<input type="hidden" name="option" value="com_mymuse" /> 
	<input type="hidden" name="task" value="addtocart" /> 
	<input type="hidden" name="catid" value="<?php echo $product->catid; ?>" /> 
	<input type="hidden" name="Itemid" value="<?php echo $Itemid; ?>" />


<div class="mymuse">




<!-- IMAGE  -->
<?php if( ($params->get('product_show_product_image') && $product->detail_image)) :?>
		<div class="product-image">
			<img <?php if($height) : ?> style="height:<?php echo $height; ?>"
				<?php endif; ?>
				src="<?php echo JURI::Root().$product->detail_image;?>"
				alt="<?php echo $product->title;?>"
				title="<?php echo $product->title;?>" 
				id="img_<?php echo $product->id; ?>"
				/>
		</div>
<?php endif; ?>
<!-- END IMAGE  -->

<div class="product-info">
	<?php if( $params->get('show_title') ): ?>
		<h2 class="product-title"><?php echo $product->title ?></h2>
	<?php endif; ?>   

	<?php if($product->attribs->get('special_status',0) ) : ?>
	     <h3 class="pre-order-text"><?php echo JText::_($this->item->attribs->get('special_status')); ?></h3>
	 <?php endif; ?>

	<?php if( $params->get('show_release_info') ):
		echo $this->loadTemplate('release');
	endif; ?>

	<ul class="product-content">
		<?php  if ($params->get('show_intro') && $product->introtext) : ?>
		
		<li class="product-content-item">
				<div class="product-description">
            
                <?php echo $product->introtext ?>
            
            
            	<?php if($product->introtext && $product->fulltext && $params->get('show_readmore')) : ?><br />
					<a href="#readmore" class="readon"><?php echo JText::_("MYMUSE_READ_MORE"); ?>
	                <?php 
	                if ($params->get('show_readmore_title', 0) != 0) :
	                    echo JHtml::_('string.truncate', ($this->item->title), $params->get('readmore_limit'));
	                endif;
	                ?></a>
				 <?php endif; ?>

				</div>
		</li>
		<?php endif ?>


		<li class="product-content-item">
            <span class="name"><?php echo JText::_('MYMUSE_ARTIST'); ?></span>
			<span class="value">
				<?php if($this->item->artist_link) :
					$this->item->artist_title = '<a href="'.$this->item->artist_link.'">'.$this->item->artist_title.'</a>';
				endif;
				?>

				<?php echo $this->item->artist_title;?></span>
        </li>
		        
	    <?php if ($this->item->product_made_date && $this->item->product_made_date > 0) : ?>
	        <li class="product-content-item">
	            <span class="name"><?php echo JText::_('MYMUSE_PRODUCT_CREATED_LABEL'); ?></span>
			    <span class="value"><?php echo $this->item->product_made_date;?></span>
			</li>
	    <?php endif; ?>

		<?php if ($this->params->get('show_category')) : ?>
			<li class="product-content-item">
				
			<?php 	$title = $this->escape($this->item->category_title);
				$url = '<a href="'.JRoute::_(myMuseHelperRoute::getCategoryRoute($this->item->catid)).'">'.$title.'</a>';?>
				<span class="name category"><?php echo JText::_('MYMUSE_CATEGORY'); ?></span>
			<?php if ($this->params->get('link_category') and $this->item->catslug) : ?>
				<span class="value"><?php echo $url ?></span>
			<?php else : ?>
				<span class="value"><?php echo $this->item->category_title;?></span>
			<?php endif; ?>
				</span>
			</li>
		<?php endif; ?>		 


		<?php  if ($params->get('show_product_sku')) : ?>
	        <li class="product-content-item">
	            <span class="name">SKU:</span>
	            <span class="value"><?php echo $product->product_sku;?></span>
	        </li>
	    <?php endif ?>
        <?php if($product->attribs['product_coming_soon']){ ?>
	        <li class="product-content-item">
	            <h4 class="value"><?php echo JText::_("MYMUSE_COMING_SOON"); ?></h4>
	        </li>
        <?php }elseif($product->attribs['product_presale']){ ?>
	        <li class="product-content-item">
	            <h4 class="value"><?php echo JText::_("MYMUSE_PRODUCT_PREORDER"); ?></h4>
	        </li>
        <?php } ?>
            	

        <li class="product-content-item">
			<div class="value">
				<div class="product-description">
					
					<?php if($product->attribs->get('media_rls')) : ?>
					<a href="<?php echo JRoute::_('index.php?option=com_content&view=article&id='.$product->attribs->get('media_rls')); ?>" target="_blank">
						  <div class="news-rls"></div></a>
					<?php endif; ?> 
							
					<?php if($product->attribs->get('media_link')) : ?>
					<a href="<?php echo $product->attribs->get('media_link'); ?>" target="_blank">
						  <div class="pdf-rls"></div></a>
					<?php endif; ?>     
					
				</div>
			</div>
        
        </li>
    </ul>


  
<?php 
if( $params->get('show_recording_details') ):    
	echo $this->loadTemplate('recording');
endif; 
?>

 </div>

 <div style="clear: both"></div>



<?php 
if( $product->product_physical && !count($items)) : 
	echo $this->loadTemplate('physical');
endif; 
?>
	
		
<?php 
if( count($items)) : 
	echo $this->loadTemplate('items');
endif; 
?>

<?php 
if(count($tracks) && $params->get('product_show_tracks', 1)) : 
	echo $this->loadTemplate('tracks');
endif; 
?>


</form>


<?php 
if($product->introtext && $product->fulltext && $params->get('show_readmore')) : ?>
<a name="readmore"></a>
<?php  echo $product->fulltext;
endif;
?>

<?php if(isset($this->recommends_display)) : ?>
<!-- START RECOMMENDS -->
<?php echo $this->recommends_display; ?>
<!-- END RECOMMENDS -->
<?php endif; ?>

<?php echo $this->item->event->afterDisplayProduct; ?>

<!--  end PRODUCT VIEW -->
</div>

<div id='my_overlay' style="display: none"></div>
<div id='my_modal' style="display: none">
	<div id='my_content'>No JavaScript!</div>
	<a href='#' id='my_close'>close</a>
</div>

