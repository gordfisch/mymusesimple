<?php
/**
 * @version		$Id: default_no_auth.php 1008 2013-06-12 20:16:15Z gfisch $
 * @package		mymuse
 * @copyright	Copyright © 2010 - Arboreta Internet Services - All rights reserved.
 * @license		GNU/GPL
 * @author		Gordon Fisch
 * @author mail	info@mymuse.ca
 * @website		http://www.mymuse.ca
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>
<h3><?php echo JText::_( 'MYMUSE_ALERTNOTAUTH' ); ?></h3>
