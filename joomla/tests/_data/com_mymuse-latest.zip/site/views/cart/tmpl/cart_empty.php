<?php 
/**
 * @version		$Id$
 * @package		mymuse
 * @copyright	Copyright © 2010 - Arboreta Internet Services - All rights reserved.
 * @license		GNU/GPL
 * @author		Gordon Fisch
 * @author mail	info@joomlamymuse.com
 * @website		http://www.joomlamymuse.com
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<h2><?php echo JText::_('MYMUSE_SHOPPING_CART'); ?></h2> 
<dl id="system-message">
	<dt class="message">Message</dt>
	<dd class="message message">
	<ul>
		<li><?php echo JText::_('MYMUSE_YOUR_CART_IS_EMPTY'); ?></li>
	</ul>
	</dd>
</dl>