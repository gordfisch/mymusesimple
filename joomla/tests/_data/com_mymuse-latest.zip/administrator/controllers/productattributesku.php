<?php
/**
 * @version     $Id: productattributesku.php 1263 2014-04-25 17:58:38Z gfisch $
 * @package     com_mymuse3
 * @copyright   Copyright (C) 2011. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Gord Fisch arboreta.ca
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Productattribute controller class.
 */
class MymuseControllerProductattributesku extends JControllerForm
{

    function __construct() {
        $this->view_list = 'productattributeskus';
        parent::__construct();
    }


    function save($key = NULL, $urlVar = NULL)
    {
    	$app   		= JFactory::getApplication();
    	$input 		= $app->input;
    	$post 		= $input->post->getArray();
		$form 		= $post['jform'];
		$id 		= $form['id'];
		
 		$app->setUserState('com_mymuse.edit.productattributesku.data', $form);

    	$arr['extra_base'] = $form['extra_base'];
    	$arr['extra_css'] = $form['extra_css'];

    	$bases = preg_split('/\r\n|\r|\n/', $form['extra_base']);
    	$csss = preg_split('/\r\n|\r|\n/', $form['extra_css']);

    	if($form['extra_base'] != '' && $form['extra_css'] != ''){
    		
    		if( count($bases) != count($csss) ){
    			$msg = "The base value count does not match the css count.";
    			$this->setRedirect( 'index.php?option=com_mymuse&task=productattributesku.edit&id='.$id, $msg );
    			return false;

    		}
    	}


    	$app->setUserState('com_mymuse.edit.productattributesku.data', null);	
    	return parent::save();

    }

    function return()
    {
        $app        = JFactory::getApplication();
        $input      = $app->input;
        $id = $input->get('parentid');
        $this->setRedirect( 'index.php?option=com_mymuse&view=product&layout=listitems&id='.$id, $msg );


    }
}