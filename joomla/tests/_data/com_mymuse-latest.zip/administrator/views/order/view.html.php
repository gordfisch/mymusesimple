<?php
/**
 * @version     $Id$
 * @package     com_mymuse3
 * @copyright   Copyright (C) 2011. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Gord Fisch arboreta.ca
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

/**
 * View to edit
 */
class MymuseViewOrder extends JViewLegacy
{
	protected $state;
	protected $item;
	protected $form;
	protected $lists;

	/**
	 * Display the view
	 */
	public function display($tpl = null)
	{
		
		$this->state	= $this->get('State');
		$this->item		= $this->get('Item');
		$this->form		= $this->get('Form');
		$this->params   = MyMuseHelper::getParams();
		$this->lists	= $this->get('Lists');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}
		
		$input  = JFactory::getApplication()->input;
		$task = $input->get('task', null);


		


		switch ($task)
		{
			case "mailcustomer":
			{
				include_once( JPATH_SITE.DS.'components'.DS.'com_mymuse'.DS.'mymuse.class.php' );
				$MyMuseStore	=& MyMuse::getObject('store','models');
				$this->store			= $MyMuseStore->getStore();
				
				// Process order plugins
    			$dispatcher				= JDispatcher::getInstance();
    			$extra 					= '';
				JPluginHelper::importPlugin('system');
				$results 				= $dispatcher->trigger('onRenderOrder', array ( ));
				if(isset($results[0])){
					$extra = $results[0];
				}
				$this->extra = $extra;


				JPluginHelper::importPlugin('mymuse');
				$results 				= $dispatcher->trigger('onAfterMyMusePayment', array() );
				$my_email_msg 			= '';
				foreach($results as $res){
					$arr = explode(":",$res);
				    $p = array_shift($arr);
				    $my_email_msg .= implode(":",$arr);
				}
				$this->my_email_msg = $my_email_msg;

				$shopper = $this->item->user;
				@list($shopper->first_name,$shopper->last_name) = explode(" ",$shopper->name);
				$shopper->address1 		= isset($shopper->profile['address1'])? $shopper->profile['address1'] : '';
				$shopper->address2 		= isset($shopper->profile['address2'])? $shopper->profile['address2'] : '';
				$shopper->city 			= isset($shopper->profile['city'])? $shopper->profile['city'] : '';
				$shopper->region 		= isset($shopper->profile['region'])? $shopper->profile['region'] : '';
				$shopper->region 		= isset($shopper->profile['region_name'])? $shopper->profile['region_name'] : $shopper->region;
				$shopper->postal_code 	= isset($shopper->profile['postal_code'])? $shopper->profile['postal_code'] : '';
				$shopper->country		= isset($shopper->profile['country'])? $shopper->profile['country'] : '';
				$shopper->phone			= isset($shopper->profile['phone'])? $shopper->profile['phone'] : '';
				$shopper->mobile		= isset($shopper->profile['mobile'])? $shopper->profile['mobile'] : '';
				$shopper->fax			= isset($shopper->profile['fax'])? $shopper->profile['fax'] : '';
				$this->shopper 			= $shopper;

				$currency = MyMuseHelper::getCurrency($this->item->order_currency);
        		$this->item->currency = $currency;
        		$this->item->do_html = 0;
        		
				$this->params->set('my_currency_code',$currency['currency_code']);
				$this->params->set('my_currency_symbol',$currency['symbol']);

				parent::display('customer');
				
			} break;
			
			default:
			{
				$this->addToolbar();
				parent::display($tpl);
			}
			
			
		}
		
		
	}

	/**
	 * Add the page title and toolbar.
	 */
	protected function addToolbar()
	{
		$input  = JFactory::getApplication()->input;
		$input->set('hidemainmenu', true);

		$user		= JFactory::getUser();
		$isNew		= ($this->item->id == 0);
        if (isset($this->item->checked_out)) {
		    $checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $user->get('id'));
        } else {
            $checkedOut = false;
        }
		$canDo		= MymuseHelper::getActions();

		JToolBarHelper::title(JText::_('MYMUSE').' : '.JText::_('COM_MYMUSE_TITLE_ORDER'), 'mymuse.png');

		// If not checked out, can save the item.
		if (!$checkedOut && ($canDo->get('core.edit')||($canDo->get('core.create'))))
		{

			JToolBarHelper::apply('order.apply', 'JTOOLBAR_APPLY');
			JToolBarHelper::save('order.save', 'JTOOLBAR_SAVE');
		}


		if (empty($this->item->id)) {
			JToolBarHelper::cancel('order.cancel', 'JTOOLBAR_CANCEL');
		}
		else {
			JToolBarHelper::cancel('order.cancel', 'JTOOLBAR_CLOSE');
		}
		JToolBarHelper::help('', false, 'https://www.joomlamymuse.com/support/documentation/documentation-mymusesimple/order-view?tmpl=component');
		
	}
}
