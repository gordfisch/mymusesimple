<div class="pull-left span5">
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_weight'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_weight'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_weight_uom'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_weight_uom'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_length'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_length'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_width'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_width'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_height'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_height'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_lwh_uom'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_lwh_uom'); ?>
			</div>
		</div>
</div>