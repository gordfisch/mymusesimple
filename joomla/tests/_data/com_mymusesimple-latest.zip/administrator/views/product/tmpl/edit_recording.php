<div class="pull-left span5">
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_made_date'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_made_date'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_full_time'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_full_time'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_country'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_country'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_publisher'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_publisher'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_producer'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_producer'); ?>
			</div>
		</div>
		<div class="control-group">
			<div class="control-label">
				<?php echo $this->form->getLabel('product_studio'); ?>
			</div>
			<div class="controls">
				<?php echo $this->form->getInput('product_studio'); ?>
			</div>
		</div>
	

</div>