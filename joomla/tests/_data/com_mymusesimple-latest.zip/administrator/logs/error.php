#
#<?php die('Forbidden.'); ?>
#Date: 2019-02-06 15:33:01 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2019-02-06T15:33:01+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
